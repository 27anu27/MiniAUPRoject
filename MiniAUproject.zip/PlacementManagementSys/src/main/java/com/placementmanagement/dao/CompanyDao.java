package com.placementmanagement.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.jdbc.core.RowMapper;

import com.placementmanagement.model.*;

public class CompanyDao {
	@Autowired
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}  
	public int save(Company c){  

		String cid=c.getCname()+c.getArrivaldate().substring(6);
		
	    String sql="insert into Company(cid,cname,lpa,branch,profile,arrivaldate) values('"+cid+"','"+c.getCname()+"',"+c.getLpa()+",'"+c.getBranch()+"','"+c.getProfile()+"','"+c.getArrivaldate()+"')";  
	    return template.update(sql);  
	}  
	public int update(Company c){  
	    String sql="update Company set cname='"+c.getCname()+"', lpa="+c.getLpa()+", branch='"+c.getBranch()+"', profile='"+c.getProfile()+"' where cid='"+c.getCid()+"' ";  
	    return template.update(sql);
	}    
	 public int placedtable(int sid,String cid,int year,float package1) {
		 String sql="insert into placed(sid,cid,year,lpa) values(?,?,?,?)";
		 return template.update(sql,sid,cid,year,package1);
		
	 }
 
	 public List<Company> getCompany(){  
		   
		    return template.query("select * from company",new RowMapper<Company>(){  
		        @Override  
		        public Company mapRow(ResultSet rs, int rownumber) throws SQLException {  
		        	Company e=new Company();  
		            e.setCid(rs.getString(1));  
		            e.setCname(rs.getString(2));  
		            e.setArrivaldate(rs.getString(3));  
		            e.setLpa(rs.getFloat(4));
		            e.setBranch(rs.getString(5));
		            e.setProfile(rs.getString(6));
		            return e;  
		        }  
		        });  
	}
	 

	 public int  yearwiseCont(String cname,int year) {
		  
		    String cid=cname+year;
		    String sql="select count(*) from placed where cid='"+cid+"'";
		     return template.queryForObject(sql,Integer.class);
		    
		    }
		  
	 public float yearwiseAvgPckg(String cname,int year) {
		   
		   String cid=cname+year;
		   String sql="select avg(lpa) from placed where cid='"+cid+"'";
		   return template.queryForObject(sql, Float.class);
		   }
		public int updateapplied(String cid, int sid) {
			String sql="insert into applied(cid,sid) values(?,?)";
			
			return template.update(sql,cid,sid);
		}
	 
	 
	 
	 
}

	
