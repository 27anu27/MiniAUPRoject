 angular.module('myApp').controller('editcompany', function($scope,$http,$state,variables) {

            
			$scope.editc=function(companydetails){
				console.log(companydetails);
				companydetails.cid=variables.cid;
				companydetails.cname=variables.cname;
				companydetails.arrivaldate=variables.arrival;
				
				$http.post('http://localhost:8080/PlacementManagementSys/updateCompanies', companydetails)
				.then(
				function (response) {
                
				alert("successfully edited");
				$state.transitionTo("admin");
				}).
				catch(function(err){
					console.log("error dude :(");
				});
				
        
   
				
				
		}
        });