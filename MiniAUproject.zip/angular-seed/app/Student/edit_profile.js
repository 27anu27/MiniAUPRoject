
 
angular.module('myApp').controller('updateProfile', function($scope,$http,$q,variables,$state) {
			
			
            var sid=variables.credentials.sid;
			console.log(sid);
			$scope.change=function(edit){
				
				
				edit.sid=sid;
				console.log(edit);
				$http.post('http://localhost:8080/PlacementManagementSys/updateprofile',edit)
				.then(
				function (response) {
					
				alert("successfully updated");
				$state.go("student",{});
				
				}).
				catch(function(err){
					console.log("error dude :(");
				});
				// function(errResponse){
    //             console.error('Error while logging in');
    //             deferred.reject(errResponse);
				// alert("error!");
            
      
				
				
		}
        });