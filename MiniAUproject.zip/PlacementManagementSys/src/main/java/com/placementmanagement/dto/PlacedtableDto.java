package com.placementmanagement.dto;

public class PlacedtableDto {
    String cname;
    int year;
    int studentscount;
	float package1;
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getStudentscount() {
		return studentscount;
	}
	public void setStudentscount(int studentscount) {
		this.studentscount = studentscount;
	}
	public float getPackage1() {
		return package1;
	}
	public void setPackage1(float package1) {
		this.package1 = package1;
	}

}
