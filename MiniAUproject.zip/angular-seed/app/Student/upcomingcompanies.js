
 angular.module('myApp').controller('getCompany', function($scope,variables,$state,$http){
	
	console.log("hi");
	
	$http.post('http://localhost:8080/PlacementManagementSys/upcomingcompanies')
				.then(
				function (response) {
					console.log(response);
              $scope.upcomingcompanies=response.data;
			  console.log(upcomingcompanies);
			   
				}).
				catch(function(err){
					console.log("error dude :(");
				});
	
	
	
	
    $scope.apply = function(cid){
      var store={cid:cid,sid:variables.credentials.sid};
	  console.log(store);

	  $http.post('http://localhost:8080/PlacementManagementSys/apply',store)
				.then(
				function (response) {
               
				alert("successfully applied");
				$state.go("student");
				}).
				catch(function(err){
					$state.go("student");
					console.log("error dude :(");
				});
    };
    
});
