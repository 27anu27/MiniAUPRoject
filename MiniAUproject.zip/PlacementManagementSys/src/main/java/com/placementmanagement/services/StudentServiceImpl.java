package com.placementmanagement.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import org.springframework.stereotype.Service;

import com.placementmanagement.dao.StudentDao;

import com.placementmanagement.model.Student;
@Service
public class StudentServiceImpl implements StudentService{
	ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("springrest-servlet.xml");
	@Autowired 
	private StudentDao studentdao;
	
	@Override
	public void saveStudent(Student x) 
	{
		studentdao.save(x);
		
		
	}
	@Override

	public boolean validateStudent(Student student) {
		try {
		Student x=studentdao.getStudentById(student.getSid());
		if(x.getPassword().equals(student.getPassword()))
			return true;
		}catch(org.springframework.dao.EmptyResultDataAccessException e) {
			return false;
			
		}
		
		return false;	
	}
	
	@Override
	public Student findById(long id) {
		
		List<Student> x=studentdao.getStudents();
		for(Student q:x)
		{
			if(q.getSid()==id)
		          return q;
	}
	return null;

}
	@Override
	public void updatestudent(Student currentStudent) {
		
		studentdao.update(currentStudent);
	}
	
	
	

}
