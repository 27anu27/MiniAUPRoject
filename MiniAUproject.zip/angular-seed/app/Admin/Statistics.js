






angular.module('myApp').controller('Stats', function($scope,$http,$q) {
		
            
			$scope.statistics=function(stats){
				
			
				var deferred = $q.defer();
				console.log(stats);
				$http.post('http://localhost:8080/PlacementManagementSys/statistics',stats)
				.then(
				function (response) {
					console.log(response.data);
               placedtabledata=response.data;
			   $scope.cname=placedtabledata.cname;
			    $scope.year=placedtabledata.year;
				 $scope.studentscount=placedtabledata.studentscount;
				  $scope.package1=placedtabledata.package1;
				
				}).
				catch(function(err){
					alert("no data found");
				});
	
            
        
        return deferred.promise;
				
				
		}
        });