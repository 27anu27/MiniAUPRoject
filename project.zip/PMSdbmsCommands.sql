create database pms;
use pms;
create table student(sid int not null primary key,name varchar(20),cgpa decimal(4,2),password varchar(20),email varchar(30),branch varchar(20),previousexperience varchar(50),securityanswer varchar(20));
create table company(cid varchar(20) not null primary key, cname varchar(15) not null,arrivaldate varchar(10),lpa decimal(4,2),branch varchar(20),profile varchar(50));
create table placed(sid int not null,cid varchar(20) not null, year int,lpa decimal(4,2),primary key(sid,cid),foreign key(sid) references student(sid),foreign key(cid) references company(cid));
create table applied(sid int not null, cid varchar(20) not null,primary key(sid,cid),foreign key(sid) references student(sid),foreign key(cid) references company(cid));
