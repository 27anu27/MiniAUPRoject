package com.placementmanagement.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.placementmanagement.dto.ApplyCompanyDto;
import com.placementmanagement.dto.PlacedTableEntryDto;
import com.placementmanagement.dto.PlacedtableDto;
import com.placementmanagement.dto.PlacedtableDtorequest;
import com.placementmanagement.model.Company;

public interface CompanyService {
	
	void addCompany(Company company) ;
	
	public List<Company> upcomingcompanies() ;

	public void updateCompany(Company company) ;
	
	///public List<Company> notifications() ;
	
	public Company getCompanyById(String cid) ;

	PlacedtableDto statistics(PlacedtableDtorequest placedtabledtorequest);

	void placedtableupdate(PlacedTableEntryDto placedtableentrydto);

	void updateapplied(ApplyCompanyDto applycompanydto);

	


}
