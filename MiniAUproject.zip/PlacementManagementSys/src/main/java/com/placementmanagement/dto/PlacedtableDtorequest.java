package com.placementmanagement.dto;

public class PlacedtableDtorequest {
int year;
String cname;
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}

}
