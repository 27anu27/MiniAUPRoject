package com.placementmanagement.dto;

public class PlacedTableEntryDto {

	
	
	
		 private int sid;
		 private String cname;
		 private int year;
		 private float  lpa;
		 public int getSid() {
		  return sid;
		 }
		 public void setSid(int sid) {
		  this.sid = sid;
		 }
		
		 
		 public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public float getLpa() {
		  return lpa;
		 }
		 public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		public void setLpa(float lpa) {
		  this.lpa = lpa;
		 }
		 
		
}
