package com.placementmanagement.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.placementmanagement.dto.PlacedTableEntryDto;
import com.placementmanagement.dto.PlacedtableDto;
import com.placementmanagement.dto.PlacedtableDtorequest;
import com.placementmanagement.model.Company;
import com.placementmanagement.model.Student;
import com.placementmanagement.services.CompanyService;
import com.placementmanagement.services.StudentServiceImpl;

@RestController

public class AdminController {


	@Autowired
	StudentServiceImpl studentService;  //Service which will do all data retrieval/manipulation work
	@Autowired
	CompanyService companyService;
	@RequestMapping(value = "/validateadmin", method = RequestMethod.POST)
    public ResponseEntity<Void> validate(@RequestBody Student student) {

         if(student.getPassword().equals("dummypassword"))
        	 return new ResponseEntity<>(HttpStatus.OK);
         else
        	 return new ResponseEntity<>(HttpStatus.CONFLICT);
}

	@RequestMapping(value = "/addcompany", method = RequestMethod.POST)
	public ResponseEntity<Void> add(@RequestBody Company company){
		companyService.addCompany(company);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	
	
	
	@RequestMapping(value = "/placedtableupdate", method = RequestMethod.POST)
	public ResponseEntity<Void> placedtableupdate(@RequestBody PlacedTableEntryDto placedtableentrydto){
		companyService.placedtableupdate(placedtableentrydto);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	
	
	
	@RequestMapping(value = "/updateCompanies", method = RequestMethod.POST)
	public ResponseEntity<Void> update(@RequestBody Company company){
	
	        companyService.updateCompany(company);
	        return new ResponseEntity<>( HttpStatus.OK);
	    
		
	}
	
	
	@RequestMapping(value = "/statistics", method = RequestMethod.POST, produces = "application/json")
	public PlacedtableDto statistics(@RequestBody PlacedtableDtorequest placedtabledtorequest){
		
		PlacedtableDto placedtableDto= companyService.statistics(placedtabledtorequest);
		return (placedtableDto);
		
	}
	
	
	

}

