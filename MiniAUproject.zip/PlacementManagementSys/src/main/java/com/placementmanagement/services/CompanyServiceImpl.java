package com.placementmanagement.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.placementmanagement.dao.CompanyDao;

import com.placementmanagement.dto.ApplyCompanyDto;
import com.placementmanagement.dto.PlacedTableEntryDto;
import com.placementmanagement.dto.PlacedtableDto;
import com.placementmanagement.dto.PlacedtableDtorequest;
import com.placementmanagement.model.Company;



@Service
public class CompanyServiceImpl implements CompanyService{
	@Autowired
	private CompanyDao companydao;
	
	@Override
	public void addCompany(Company company) {
		companydao.save(company);

	}

	@Override
	public List<Company> upcomingcompanies() {
		LocalDate localDate = LocalDate.now();
      String h = (DateTimeFormatter.ofPattern("yyy/MM/dd").format(localDate));
      
      
      
      String m=(h.substring(5,7));
      
      int m1=Integer.parseInt(m);
   
      int d=Integer.parseInt(h.substring(8));
      
   int present=12*m1+d;
   
		List<Company> list=companydao.getCompany();
		List<Company> comlist=new ArrayList<>();
		for(Company x: list)
		{
			
			int db=12*Integer.parseInt(x.getArrivaldate().substring(3,5))+Integer.parseInt(x.getArrivaldate().substring(0,2));
		
			if(present-db<=0)
			
		         comlist.add(x);
		}

		return comlist;
		
	}

	@Override
	public void updateCompany(Company company) {
		companydao.update(company);
	}



	@Override
	public Company getCompanyById(String cid) {

		List<Company> x=companydao.getCompany();
		for(Company q:x)
		{
			if(q.getCid()==cid)
		          return q;
	}
	return null;
		
	}

	@Override
	public PlacedtableDto statistics(PlacedtableDtorequest placedtabledtorequest) {
		
		String cname=placedtabledtorequest.getCname();
		int year=placedtabledtorequest.getYear();
		PlacedtableDto placedtableDto=new PlacedtableDto();
		int count=companydao.yearwiseCont(cname,year);
		float package1=companydao.yearwiseAvgPckg(cname, year);
		placedtableDto.setCname(cname);
		placedtableDto.setYear(year);
		placedtableDto.setPackage1(package1);
		placedtableDto.setStudentscount(count);

	return placedtableDto;
	}

	@Override
	public void placedtableupdate(PlacedTableEntryDto placedtableentrydto) {
		int sid=placedtableentrydto.getSid();
		int year=placedtableentrydto.getYear();
		String cname=placedtableentrydto.getCname();
		String cid=cname+year;
		companydao.placedtable(sid, cid, year, placedtableentrydto.getLpa());
	}
//

	@Override
	public void updateapplied(ApplyCompanyDto applycompanydto) {
		String cid=applycompanydto.getCid();
		int sid=applycompanydto.getSid();
		companydao.updateapplied(cid,sid);
	}
	
	
	

}
