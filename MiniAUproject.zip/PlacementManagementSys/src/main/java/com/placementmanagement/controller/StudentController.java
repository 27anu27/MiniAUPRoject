package com.placementmanagement.controller;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;


import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.placementmanagement.dto.ApplyCompanyDto;
import com.placementmanagement.model.Company;
import com.placementmanagement.model.Student;
import com.placementmanagement.services.CompanyService;
import com.placementmanagement.services.StudentService;





@RestController
public class StudentController {
 //Service which will do all data retrieval/manipulation work
    @Autowired
    CompanyService companyService;
    
    @Autowired
    StudentService studentService; 

    @RequestMapping(value = "/validate", method = RequestMethod.POST)
    public ResponseEntity<Void> validate(@RequestBody Student student, HttpServletRequest request) {

    Boolean y= studentService.validateStudent(student);

     if(y)
    return new ResponseEntity<>(HttpStatus.OK);
     else
    	 return new ResponseEntity<>(HttpStatus.CONFLICT);
     
    }
 @RequestMapping(value = "/signUps", method = RequestMethod.POST)
    public ResponseEntity<Void> createStudent(@RequestBody Student student) {

    	Student currentStudent = studentService.findById(student.getSid());
        if (currentStudent!=null) {

            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
 
        studentService.saveStudent(student);
        return new ResponseEntity<>( HttpStatus.CREATED);
  
    }
 
 
 
 //Upadting user detailes
 
     @RequestMapping(value = "/updateprofile", method = RequestMethod.POST)
    public ResponseEntity<Void> updatestudent( @RequestBody Student student) {
    
         
        Student currentStudent = studentService.findById(student.getSid());
         
       
        currentStudent.setName(student.getName());
        currentStudent.setCgpa(student.getCgpa());
        currentStudent.setEmail(student.getEmail());
        currentStudent.setBranch(student.getBranch());
        currentStudent.setPreviousexperience(student.getPreviousexperience()); 
        studentService.updatestudent(currentStudent);
        return new ResponseEntity<>( HttpStatus.OK);
    }
    
    
    @RequestMapping(value="/upcomingcompanies",method = RequestMethod.POST, produces = "application/json")
    public List<Company> upcomingcompanies()
    {
    	List<Company> companies = companyService.upcomingcompanies();
    	
    	if (!companies.isEmpty()) {
            return companies;
        }
       return companies;
    }
    
    
      @RequestMapping(value="/apply",method=RequestMethod.POST)
       public ResponseEntity<Void> apply( @RequestBody ApplyCompanyDto applycompanydto)
       {
          companyService.updateapplied(applycompanydto);
          return new ResponseEntity<>( HttpStatus.OK);
       
       }

}
    
