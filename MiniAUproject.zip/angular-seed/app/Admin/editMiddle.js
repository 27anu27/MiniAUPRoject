angular.module('myApp').controller('editMiddle', function($scope,variables,$state,$http){
	
	console.log("hi");
	
	$http.post('http://localhost:8080/PlacementManagementSys/upcomingcompanies')
				.then(
				function (response) {
					console.log(response);
              $scope.upcomingcompanies=response.data;
			  console.log(upcomingcompanies);
			   
				}).
				catch(function(err){
					console.log("error dude :(");
				});
	
	
	
	
    $scope.change = function(cid, cname, arrival){
      variables.cid=cid;
	  variables.cname=cname;
	  variables.arrival=arrival;
	  
	
	  console.log(cid);
	  console.log(cname);
	  console.log(arrival);
	  $state.transitionTo("editCompany");
	
    
}});
