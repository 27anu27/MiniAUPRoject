1.Install the following:
	-mySQL (database)
	-maven
	-tomcat (server)
	-spring 4 (framework)
	-npm and bower (anguarjs)
	-eclipse oxgen

2.Create the database and populate the tables (.sql file)

3.Open the project in eclipse IDE. Launch the backend server after dependencies are installed.

4.Start the localhost:8000 in the angular-seed folder by typing "npm start".

5.If you are a new user, sign up as a student. If  admin, use "pwd" as password with any creative username of your choice :P

6.You are good to go! Also, say wow after going through the project xD.