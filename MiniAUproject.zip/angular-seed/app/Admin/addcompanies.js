 angular.module('myApp').controller('addcompany', function($scope,$http,$q) {

            
			$scope.addcompany=function(companydetails){
				
				//add student
				
				//svar d=JSON.parse(details);
				
				var deferred = $q.defer();
				$http.post('http://localhost:8080/PlacementManagementSys/addcompany', companydetails)
				.then(
				function (response) {
                deferred.resolve(response.data);
				alert("successfully added company");
				}).
				catch(function(err){
					alert("already added this company");
				});
				
        
        return deferred.promise;
				
				
		}
        });