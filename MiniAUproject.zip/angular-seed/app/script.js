// script.js

    // create the module and name it scotchApp
        // also include ngRoute for all our routing needs
	
    var app =angular.module('myApp', ['ui.router']);
	app.config(['$stateProvider',function($stateProvider) {
		// route for the home page
		
        $stateProvider.state('home',{
				url : "/", 
                templateUrl : "Homepage/index.html"
			});
		$stateProvider.state('student',{
				url : "/student", 
                templateUrl : "Student/StudentIndex.html"
			});
		$stateProvider.state('admin',{
				url : "/admin", 
                templateUrl : "Admin/AdminIndex.html"

            });


		$stateProvider.state('stats',{
				url : "/admin/stats", 
                templateUrl : "Admin/Statistics.html"

            });

		$stateProvider.state('addcompany',{
				url : "/admin/addCompany", 
                templateUrl : "Admin/addCompany.html"
                 });

        $stateProvider.state('edit_profile',{
				url : "/student/edit_profile", 
                templateUrl : "Student/edit_profile.html"

            });
           $stateProvider.state('upcomingcompanies',{
				url : "/student/upcomingcompanies/", 
                templateUrl : "Student/upcomingcompanies.html",
                controller:'getCompany'

            });
              $stateProvider.state('placedtableentry',{
				url : "/admin/placedtableentry", 
                templateUrl : "Admin/placedtableentry.html"

            });
               $stateProvider.state('editCompany',{
				url : "/admin/editCompany", 
                templateUrl : "Admin/editcompanies.html"

            });
                $stateProvider.state('editMiddle',{
				url : "/admin/editMiddle", 
                templateUrl : "Admin/editMiddle.html"

            });


            
    }]);
	// create the controller and inject Angular's $scope
    app.controller('mainController', function($scope) {
        // create a message to display in our view
        console.log("hfgjhgf");
    });

    app.controller('studentController', function($scope) {
        $scope.message = 'Look! I am an about page.';
    });

    app.controller('adminController', function($scope) {
        $scope.message = 'Contact us! JK. This is just a demo.';
    });
	
	
	
	
        //var app = angular.module('myApp',[]);
		
		/* app.contants */
        app.controller('myCtrl', function($scope,$state,$location,$http,$q,variables) {
			
            // $scope.username= "qwert";
            // $scope.password= "gfdg";
			
			
			$scope.login=function(credentials){
				//alert("You clicked login button!");
				var path;
				if($scope.who){
				//true then student login
				//credentials.username=parseInt(credentials.username);
				var deferred = $q.defer();

				alert("Student Login");
				$http.post('http://localhost:8080/PlacementManagementSys/validate', credentials)
				.then(
				function (response) {
					console.log(response);
                deferred.resolve(response.data);
                variables.credentials=credentials;
                console.log(variables.credentials);
                $state.transitionTo("student");
				
				}).
				catch(function(err){
					console.log("error dude :(",err);
					alert("wrong userid or password");
					 $state.transitionTo("home");
				});
				
				
				//$state.go("student", null, { reload: false, inherit: true, notify: true });
				
			}
			else{
				//false then admin login
				alert("Admin Login");
				
				if(credentials.password===("pwd"))
				{	
					console.log(credentials.password);
					path = 'admin';

				$state.transitionTo("admin");}
				else
					alert("wrong userid or password");
			   // $state.go("admin", null, { reload: false, inherit: true, notify: true });
			//$timeout($state.go.bind(null, 'admin'), 3000);
			
			}
			// alert(path.toString());
			// alert("Asdas");	
			// $state.transitionTo('home');		// window.location=path;
		}
				
        });
        
		
		
		//contrller for student sign up
        app.controller('myCtrl2', function($scope,$http,$q) {
			// $scope.details={ 'id': 
            // $scope.id= "";
            //$scope.details.fullname= "asd";
            // $scope.password= "";
            // $scope.branch= "";
            // $scope.email= "";
            
			$scope.signup=function(details){
				
				//add student
				
				//svar d=JSON.parse(details);
				
				var deferred = $q.defer();
				$http.post('http://localhost:8080/PlacementManagementSys/signUps', details)
				.then(
				function (response) {
                deferred.resolve(response.data);
				alert("successfully registered");
				}).
				catch(function(err){
					alert("User already exists");
				});
				// function(errResponse){
    //             console.error('Error while logging in');
    //             deferred.reject(errResponse);
				// alert("error!");
            
        
        return deferred.promise;
				
				
		}
        });
		//adminLogout
		function adminLogout(){
			alert("admin has successfully logged out");
			//destroy session here
		}
		
		app.controller('studIndex', function($scope,$state) {


			$scope.openUpdateProfile=function(){
				console.log("inside profile");
				$state.transitionTo("edit_profile");
			}
			$scope.openStats=function(){
				console.log("inside stats");
				$state.transitionTo("stats");
			}
			$scope.openNotifications=function(){
				console.log("inside notifications");
				$state.transitionTo("upcomingcompanies");
			}
			$scope.openResume=function(){
				console.log("inside resume");
			}
		});
//services


app.service('variables', function() {
    this.credentials={sid:0,password:""};
    this.cid="";
    this.cname="";
    this.arrival="";
    
});