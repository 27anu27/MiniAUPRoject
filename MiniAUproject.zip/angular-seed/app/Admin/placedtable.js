 angular.module('myApp').controller('Placedtable', function($scope,$http,$q) {

            
			$scope.Placedtable=function(placedtable){
				
				//add student
				
				//svar d=JSON.parse(details);
				
				var deferred = $q.defer();
				$http.post('http://localhost:8080/PlacementManagementSys/placedtableupdate', placedtable)
				.then(
				function (response) {
                deferred.resolve(response.data);
				alert("successfully added");
				}).
				catch(function(err){
					alert("Invalid Entry");
				});
				// function(errResponse){
    //             console.error('Error while logging in');
    //             deferred.reject(errResponse);
				// alert("error!");
            
        
        return deferred.promise;
				
				
		}
        });