
        //var app = angular.module('myApp',[]);
		
		
        // angular.module('myApp').controller('myCtrl', function($scope,$location,$http,$state) {
			
            // $scope.username= "qwert";
            // $scope.password= "gfdg";
			
			
			// $scope.login=function(){
				// alert("You clicked login button!");
				// var path;
				// if($scope.who){
				// true then student login
				// alert("Student Login");
				// path = 'student';
			// }
			// else{
				// false then admin login
				// alert("Admin Login");
				// path = 'admin';
			
			// }
			// alert(path.toString());
			// $state.transition(path);			// window.location=path;
		// }
				
        // });
        
        // app.controller('myCtrl2', function($scope,$http) {
            // $scope.id= "";
            // $scope.fullname= "asd";
            // $scope.password= "";
            // $scope.branch= "";
            // $scope.email= "";
			// $scope.signup=function(){
				// alert("New Student Created, now login using same credentials.");
				// add student
				
		// }
        // });
		
		